"""GUI package initialization."""

from .main_window import MainWindow