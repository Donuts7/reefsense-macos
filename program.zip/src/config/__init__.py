"""GUI package initialization."""

from .constants import CLASS_NAMES_HC, CLASS_NAMES_GROUPS, CLASS_NAMES_OTHER
