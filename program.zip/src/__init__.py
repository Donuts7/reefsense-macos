"""
Coral Analysis Tool package initialization.
"""